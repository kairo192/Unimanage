import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { colors, spacing, borderRadius } from '../theme';

const T = {
  en: { profile: 'My Profile', name: 'Name', email: 'Email', studentNumber: 'Student Number', room: 'Room', logout: 'Log Out', logoutConfirm: 'Are you sure you want to log out?', cancel: 'Cancel', confirm: 'Log Out', notAssigned: 'Not assigned' },
  ar: { profile: 'ملفي الشخصي', name: 'الاسم', email: 'البريد الإلكتروني', studentNumber: 'رقم الطالب', room: 'الغرفة', logout: 'تسجيل الخروج', logoutConfirm: 'هل أنت متأكد من تسجيل الخروج؟', cancel: 'إلغاء', confirm: 'تسجيل خروج', notAssigned: 'غير محدد' },
  fr: { profile: 'Mon Profil', name: 'Nom', email: 'Email', studentNumber: 'Numéro d\'Étudiant', room: 'Chambre', logout: 'Déconnexion', logoutConfirm: 'Êtes-vous sûr de vouloir vous déconnecter ?', cancel: 'Annuler', confirm: 'Déconnexion', notAssigned: 'Non assigné' },
};

export default function ProfileScreen({ navigation }) {
  const [lang] = useState('en');
  const [student, setStudent] = useState(null);
  const t = (k) => T[lang][k] || T.en[k];

  React.useEffect(() => {
    (async () => {
      const s = await AsyncStorage.getItem('student');
      if (s) setStudent(JSON.parse(s));
    })();
  }, []);

  const handleLogout = () => {
    Alert.alert('', t('logoutConfirm'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('confirm'), style: 'destructive',
        onPress: async () => {
          await AsyncStorage.multiRemove(['token', 'student']);
          navigation.replace('Login');
        },
      },
    ]);
  };

  const InfoRow = ({ label, value }) => (
    <View style={styles.row}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value || '-'}</Text>
    </View>
  );

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>
          {student?.name ? student.name.charAt(0).toUpperCase() : '?'}
        </Text>
      </View>

      <View style={styles.card}>
        <InfoRow label={t('name')} value={student?.name} />
        <InfoRow label={t('email')} value={student?.email} />
        <InfoRow label={t('studentNumber')} value={student?.studentNumber} />
        <InfoRow label={t('room')} value={student?.room || t('notAssigned')} />
      </View>

      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <Text style={styles.logoutText}>{t('logout')}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { alignItems: 'center', padding: spacing.lg },
  avatar: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center',
    marginBottom: spacing.lg, marginTop: spacing.md,
  },
  avatarText: { fontSize: 32, fontWeight: '700', color: colors.white },
  card: {
    backgroundColor: colors.surface, borderRadius: borderRadius.md,
    padding: spacing.lg, width: '100%',
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06, shadowRadius: 4, elevation: 2,
  },
  row: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  label: { fontSize: 14, color: colors.textSecondary },
  value: { fontSize: 14, fontWeight: '600', color: colors.text },
  logoutBtn: {
    marginTop: spacing.xl, width: '100%',
    backgroundColor: colors.error, borderRadius: borderRadius.sm,
    paddingVertical: 14, alignItems: 'center',
  },
  logoutText: { color: colors.white, fontSize: 16, fontWeight: '600' },
});