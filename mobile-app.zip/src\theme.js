export const colors = {
  primary: '#2563eb',
  primaryDark: '#1d4ed8',
  primaryLight: '#dbeafe',
  secondary: '#64748b',
  background: '#f1f5f9',
  surface: '#ffffff',
  text: '#1e293b',
  textSecondary: '#64748b',
  textLight: '#94a3b8',
  error: '#dc2626',
  errorLight: '#fef2f2',
  success: '#16a34a',
  successLight: '#f0fdf4',
  warning: '#f59e0b',
  warningLight: '#fffbeb',
  border: '#e2e8f0',
  white: '#ffffff',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const borderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  full: 999,
};

export const statusColors = {
  pending: { bg: '#fffbeb', text: '#f59e0b', dot: '#f59e0b' },
  in_progress: { bg: '#dbeafe', text: '#2563eb', dot: '#2563eb' },
  resolved: { bg: '#f0fdf4', text: '#16a34a', dot: '#16a34a' },
};