import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_BASE = 'http://localhost:5050/api';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const loginStudent = async (email, password) => {
  const res = await api.post('/auth/student-login', { email, password });
  return res.data;
};

export const getMyTickets = async () => {
  const res = await api.get('/tickets');
  return res.data;
};

export const createTicket = async (type, description) => {
  const res = await api.post('/tickets', { type, description });
  return res.data;
};

export default api;