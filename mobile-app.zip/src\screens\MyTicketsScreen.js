import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getMyTickets } from '../api/client';
import { colors, spacing, borderRadius, statusColors } from '../theme';

const T = {
  en: { myTickets: 'My Tickets', noTickets: 'No tickets yet', type: 'Type', status: 'Status', room: 'Room', submitted: 'Submitted', unknown: 'Unknown' },
  ar: { myTickets: 'تذاكري', noTickets: 'لا توجد تذاكر بعد', type: 'النوع', status: 'الحالة', room: 'الغرفة', submitted: 'مقدم', unknown: 'غير معروف' },
  fr: { myTickets: 'Mes Tickets', noTickets: 'Aucun ticket pour le moment', type: 'Type', status: 'Statut', room: 'Chambre', submitted: 'Soumis', unknown: 'Inconnu' },
};

const statusLabel = {
  en: { pending: 'Pending', in_progress: 'In Progress', resolved: 'Resolved' },
  ar: { pending: 'قيد الانتظار', in_progress: 'قيد التنفيذ', resolved: 'تم الحل' },
  fr: { pending: 'En attente', in_progress: 'En cours', resolved: 'Résolu' },
};

export default function MyTicketsScreen() {
  const [lang] = useState('en');
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const t = (k) => T[lang][k] || T.en[k];
  const sl = (k) => statusLabel[lang][k] || statusLabel.en[k];

  const fetchTickets = useCallback(async () => {
    try {
      const data = await getMyTickets();
      setTickets(data);
    } catch (err) {
      console.log('Error fetching tickets:', err?.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchTickets();
    }, [fetchTickets])
  );

  const onRefresh = () => {
    setRefreshing(true);
    fetchTickets();
  };

  const formatDate = (iso) => {
    if (!iso) return '';
    const d = new Date(iso);
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
  };

  const renderTicket = ({ item }) => {
    const sc = statusColors[item.status] || statusColors.pending;
    return (
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={[styles.badge, { backgroundColor: sc.bg }]}>
            <View style={[styles.dot, { backgroundColor: sc.dot }]} />
            <Text style={[styles.badgeText, { color: sc.text }]}>{sl(item.status)}</Text>
          </View>
          <Text style={styles.date}>{formatDate(item.created_at)}</Text>
        </View>
        <Text style={styles.type}>{t('type')}: {item.type}</Text>
        <Text style={styles.description} numberOfLines={2}>{item.description}</Text>
        <Text style={styles.room}>{t('room')}: {item.room_number || t('unknown')}</Text>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>{t('myTickets')}</Text>
      <FlatList
        data={tickets}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderTicket}
        contentContainerStyle={tickets.length === 0 ? styles.emptyContainer : styles.list}
        ListEmptyComponent={<Text style={styles.empty}>{t('noTickets')}</Text>}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background },
  header: { fontSize: 22, fontWeight: '700', color: colors.text, padding: spacing.lg, paddingBottom: spacing.md },
  list: { paddingHorizontal: spacing.lg, paddingBottom: spacing.lg },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  empty: { color: colors.textLight, fontSize: 15 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: borderRadius.full,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  badgeText: { fontSize: 12, fontWeight: '600' },
  date: { fontSize: 12, color: colors.textLight },
  type: { fontSize: 14, fontWeight: '600', color: colors.text, marginBottom: 4 },
  description: { fontSize: 13, color: colors.textSecondary, lineHeight: 18, marginBottom: 4 },
  room: { fontSize: 12, color: colors.textLight },
});