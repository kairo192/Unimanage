import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { createTicket } from '../api/client';
import { colors, spacing, borderRadius } from '../theme';

const T = {
  en: {
    reportIssue: 'Report an Issue', issueType: 'Issue Type', description: 'Description',
    descriptionPlaceholder: 'Describe the issue in detail...', submit: 'Submit',
    selectType: 'Select issue type', success: 'Issue reported successfully!',
    errorFill: 'Please select a type and write a description',
    errorSubmit: 'Failed to submit. Try again.',
    electrical: 'Electrical', plumbing: 'Plumbing', furniture: 'Furniture',
    cleaning: 'Cleaning', internet: 'Internet', other: 'Other',
  },
  ar: {
    reportIssue: 'الإبلاغ عن مشكلة', issueType: 'نوع المشكلة', description: 'الوصف',
    descriptionPlaceholder: 'صف المشكلة بالتفصيل...', submit: 'إرسال',
    selectType: 'اختر نوع المشكلة', success: 'تم الإبلاغ عن المشكلة بنجاح!',
    errorFill: 'يرجى اختيار النوع وكتابة الوصف',
    errorSubmit: 'فشل الإرسال. حاول مرة أخرى.',
    electrical: 'كهرباء', plumbing: 'سباكة', furniture: 'أثاث',
    cleaning: 'تنظيف', internet: 'إنترنت', other: 'أخرى',
  },
  fr: {
    reportIssue: 'Signaler un Problème', issueType: 'Type de Problème', description: 'Description',
    descriptionPlaceholder: 'Décrivez le problème en détail...', submit: 'Soumettre',
    selectType: 'Sélectionnez le type', success: 'Problème signalé avec succès !',
    errorFill: 'Veuillez sélectionner un type et écrire une description',
    errorSubmit: 'Échec de l\'envoi. Réessayez.',
    electrical: 'Électrique', plumbing: 'Plomberie', furniture: 'Meubles',
    cleaning: 'Nettoyage', internet: 'Internet', other: 'Autre',
  },
};

const TYPES = ['electrical', 'plumbing', 'furniture', 'cleaning', 'internet', 'other'];

export default function ReportIssueScreen({ navigation }) {
  const [lang] = useState('en');
  const [type, setType] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const t = (k) => T[lang][k] || T.en[k];

  const handleSubmit = async () => {
    if (!type || !description.trim()) {
      Alert.alert('', t('errorFill'));
      return;
    }
    setLoading(true);
    try {
      await createTicket(type, description.trim());
      Alert.alert('', t('success'), [
        { text: 'OK', onPress: () => { setType(''); setDescription(''); navigation.navigate('MyTickets'); } },
      ]);
    } catch (err) {
      Alert.alert('', t('errorSubmit'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.header}>{t('reportIssue')}</Text>

        <Text style={styles.label}>{t('issueType')}</Text>
        <View style={styles.typeRow}>
          {TYPES.map((tKey) => (
            <TouchableOpacity
              key={tKey}
              style={[styles.typeBtn, type === tKey && styles.typeBtnActive]}
              onPress={() => setType(tKey)}
            >
              <Text style={[styles.typeBtnText, type === tKey && styles.typeBtnTextActive]}>
                {t(tKey)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.label}>{t('description')}</Text>
        <TextInput
          style={styles.textArea}
          placeholder={t('descriptionPlaceholder')}
          placeholderTextColor={colors.textLight}
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={5}
          textAlignVertical="top"
        />

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleSubmit}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <Text style={styles.buttonText}>{t('submit')}</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { padding: spacing.lg },
  header: { fontSize: 22, fontWeight: '700', color: colors.text, marginBottom: spacing.lg },
  label: { fontSize: 14, fontWeight: '600', color: colors.text, marginBottom: spacing.sm, marginTop: spacing.md },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  typeBtn: {
    paddingHorizontal: 16, paddingVertical: 10,
    borderRadius: borderRadius.sm, backgroundColor: colors.surface,
    borderWidth: 1, borderColor: colors.border,
  },
  typeBtnActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  typeBtnText: { fontSize: 13, color: colors.text, fontWeight: '500' },
  typeBtnTextActive: { color: colors.white },
  textArea: {
    backgroundColor: colors.surface, borderRadius: borderRadius.sm,
    padding: spacing.md, fontSize: 14, color: colors.text,
    minHeight: 120, borderWidth: 1, borderColor: colors.border,
  },
  button: {
    backgroundColor: colors.primary, borderRadius: borderRadius.sm,
    paddingVertical: 14, alignItems: 'center', marginTop: spacing.lg,
  },
  buttonDisabled: { opacity: 0.7 },
  buttonText: { color: colors.white, fontSize: 16, fontWeight: '600' },
});