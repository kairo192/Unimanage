import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  StatusBar,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { loginStudent } from '../api/client';
import { colors, spacing, borderRadius } from '../theme';

const T = {
  en: {
    title: 'University Management',
    subtitle: 'Student Portal',
    email: 'Email',
    emailPlaceholder: 'Enter your email',
    password: 'Password',
    passwordPlaceholder: 'Enter your password',
    signIn: 'Sign In',
    errorFill: 'Please fill in all fields',
    errorLogin: 'Login failed. Check your credentials.',
    errorNetwork: 'Network error. Please try again.',
    noAccount: 'Account not activated. Contact the director.',
    en: 'English',
    ar: 'العربية',
    fr: 'Français',
  },
  ar: {
    title: 'إدارة الجامعة',
    subtitle: 'بوابة الطالب',
    email: 'البريد الإلكتروني',
    emailPlaceholder: 'أدخل بريدك الإلكتروني',
    password: 'كلمة المرور',
    passwordPlaceholder: 'أدخل كلمة المرور',
    signIn: 'تسجيل الدخول',
    errorFill: 'يرجى ملء جميع الحقول',
    errorLogin: 'فشل تسجيل الدخول. تحقق من بياناتك.',
    errorNetwork: 'خطأ في الشبكة. حاول مرة أخرى.',
    noAccount: 'الحساب غير مفعل. اتصل بالمدير.',
    en: 'English',
    ar: 'العربية',
    fr: 'Français',
  },
  fr: {
    title: 'Gestion Universitaire',
    subtitle: 'Portail Étudiant',
    email: 'Email',
    emailPlaceholder: 'Entrez votre email',
    password: 'Mot de passe',
    passwordPlaceholder: 'Entrez votre mot de passe',
    signIn: 'Connexion',
    errorFill: 'Veuillez remplir tous les champs',
    errorLogin: 'Échec de connexion. Vérifiez vos identifiants.',
    errorNetwork: 'Erreur réseau. Veuillez réessayer.',
    noAccount: 'Compte non activé. Contactez le directeur.',
    en: 'English',
    ar: 'العربية',
    fr: 'Français',
  },
};

export default function LoginScreen({ navigation }) {
  const [lang, setLang] = useState('en');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const isRtl = lang === 'ar';
  const t = (key) => T[lang][key] || T.en[key];

  const langs = ['en', 'ar', 'fr'];

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('', t('errorFill'));
      return;
    }
    setLoading(true);
    try {
      const data = await loginStudent(email.trim(), password.trim());
      await AsyncStorage.setItem('token', data.token);
      await AsyncStorage.setItem('student', JSON.stringify(data.student));
      navigation.replace('Main');
    } catch (err) {
      const msg = err?.response?.data?.error || '';
      if (msg.includes('not activated')) {
        Alert.alert('', t('noAccount'));
      } else if (msg.includes('Invalid')) {
        Alert.alert('', t('errorLogin'));
      } else {
        Alert.alert('', err?.response ? t('errorLogin') : t('errorNetwork'));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.wrapper, isRtl && styles.wrapperRtl]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />
      <View style={styles.header}>
        <Text style={styles.logo}>🏛️</Text>
        <Text style={styles.title}>{t('title')}</Text>
        <Text style={styles.subtitle}>{t('subtitle')}</Text>
      </View>

      <View style={[styles.card, isRtl && styles.cardRtl]}>
        <View style={styles.langRow}>
          {langs.map((l) => (
            <TouchableOpacity
              key={l}
              onPress={() => setLang(l)}
              style={[styles.langBtn, lang === l && styles.langBtnActive]}
            >
              <Text style={[styles.langText, lang === l && styles.langTextActive]}>
                {T[lang][l]}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <TextInput
          style={[styles.input, isRtl && styles.inputRtl]}
          placeholder={t('emailPlaceholder')}
          placeholderTextColor={colors.textLight}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />

        <TextInput
          style={[styles.input, isRtl && styles.inputRtl]}
          placeholder={t('passwordPlaceholder')}
          placeholderTextColor={colors.textLight}
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <Text style={styles.buttonText}>{t('signIn')}</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
  },
  wrapperRtl: {
    direction: 'rtl',
  },
  header: {
    backgroundColor: colors.primary,
    paddingTop: 60,
    paddingBottom: 40,
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  logo: {
    fontSize: 48,
    marginBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.white,
  },
  subtitle: {
    fontSize: 14,
    color: '#93c5fd',
    marginTop: 4,
  },
  card: {
    backgroundColor: colors.surface,
    marginHorizontal: spacing.lg,
    marginTop: -20,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  cardRtl: {
    direction: 'rtl',
  },
  langRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: spacing.lg,
    gap: spacing.sm,
  },
  langBtn: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: borderRadius.full,
    backgroundColor: colors.background,
  },
  langBtnActive: {
    backgroundColor: colors.primary,
  },
  langText: {
    fontSize: 13,
    color: colors.textSecondary,
    fontWeight: '500',
  },
  langTextActive: {
    color: colors.white,
  },
  input: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: 14,
    fontSize: 15,
    color: colors.text,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  inputRtl: {
    textAlign: 'right',
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.sm,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
});